import React from 'react';
import { Text, View, StyleSheet, Image, ScrollView } from 'react-native';
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>  Journal Брайт</Text>

      <View style={styles.newsContainer}>
        <Card style={styles.card}>
          <Image
            source={{ uri: 'https://randomuser.me/api/portraits/men/32.jpg' }}
            style={styles.image}
          />
          <Text style={styles.title}>Экологическая акция в Алматы</Text>
          <Text style={styles.content}>
            Сегодня в Алматы прошла масштабная акция по озеленению города. Более
            500 волонтёров приняли участие в посадке деревьев.
          </Text>
          <Text style={styles.author}>Автор: Сергей Иванов</Text>
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'lightgrey',
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 30,
    color: 'black',
  },
  newsContainer: {
    alignItems: 'center',
  },
  card: {
    padding: 20,
    width: '90%',
    borderRadius: 10,
    backgroundColor: 'white',
    elevation: 4,
    marginBottom: 20,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignSelf: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 10,
  },
  content: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
  },
  author: {
    fontStyle: 'italic',
    textAlign: 'center',
    color: '#555',
  },
});
